const joke = require("give-me-a-joke");
const color = require("colors");
const cowsay = require("cowsay");
joke.getRandomDadJoke(function (joke) {
  console.log(joke.rainbow);
})
console.log(cowsay.say({
  
}));

